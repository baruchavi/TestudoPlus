# TestudoPlus
A chrome extension which upgrades the Testudo class search system to make it more usable and efficient (I hope)

# Current Features
None - I haven't built any yet